from flask import Flask, request, render_template
import pickle
import numpy as np

app = Flask(__name__)

# ===== Load saved files =====
model = pickle.load(open("random.pkl", "rb"))
symptoms_dict = pickle.load(open("symptoms_dict.pkl", "rb"))
diseases_list = pickle.load(open("diseases_list.pkl", "rb"))

# Also load the dataframes you used in helper()
import pandas as pd
description = pd.read_csv("description.csv")       # adjust filenames if needed
precautions_df = pd.read_csv("precautions_df.csv")
medications = pd.read_csv("medications.csv")
diets = pd.read_csv("diets.csv")
workout_df = pd.read_csv("workout_df.csv")

# ===== Functions from notebook =====
def get_predicted_value(patient_symptoms):
    input_vector = np.zeros(len(symptoms_dict))
    for item in patient_symptoms:
        if item in symptoms_dict:   # avoid KeyError
            input_vector[symptoms_dict[item]] = 1
    return diseases_list[model.predict([input_vector])[0]]

def helper(dis):
    # Description
    desc = description[description['Disease'] == dis]['Description']
    desc = " ".join([w for w in desc])

    # Precautions
    pre = precautions_df[precautions_df['Disease'] == dis][
        ['Precaution_1', 'Precaution_2', 'Precaution_3', 'Precaution_4']
    ]
    pre = [col for col in pre.values]

    # Medications
    med = medications[medications['Disease'] == dis]['Medication']
    med = [m for m in med.values]

    # Diets
    die = diets[diets['Disease'] == dis]['Diet']
    die = [d for d in die.values]

    # Workouts
    wrkout = workout_df[workout_df['disease'] == dis]['workout']
    wrkout = [w for w in wrkout.values]

    return desc, pre, med, die, wrkout
# ====================================

# ===== Flask routes =====
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        symptoms = request.form['symptoms']
        user_symptoms = [s.strip() for s in symptoms.split(',')]

        predicted_disease = get_predicted_value(user_symptoms)
        desc, pre, med, die, wrkout = helper(predicted_disease)

        return render_template(
            'result.html',
            disease=predicted_disease,
            description=desc,
            precautions=pre[0],
            medications=med,
            diets=die,
            workout=wrkout
        )
    except Exception as e:
        return f"Error: {str(e)}"

if __name__ == "__main__":
    app.run(debug=True)

